package admin.ezezdic.com.ezezdictionary;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
EditText mType;
    Button mSearch;
    TextView mResults;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
           mType = (EditText) findViewById(R.id.typeWordTxt);
           mSearch = (Button) findViewById(R.id.findBtn);
           mResults = (TextView) findViewById(R.id.resultsTxt);

        mSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mType.getText().toString().trim().equals("คง")){
                    mResults.setText("ข้าวโพด");
                }
                else if (mType.getText().toString().trim().equals("ขี้หก")){
                    mResults.setText("โกหก");
                }
                else if (mType.getText().toString().trim().equals("แหลง")){
                    mResults.setText("พูด");
                }
                else if (mType.getText().toString().trim().equals("ไซร์")){
                    mResults.setText("ทำไม");
                }
                else if (mType.getText().toString().trim().equals("พันพรือ")){
                    mResults.setText("เป็นยังไง");
                }
                else if (mType.getText().toString().trim().equals("หวิบ")){
                    mResults.setText("โมโห");
                }
                else if (mType.getText().toString().trim().equals("เกือก")){
                    mResults.setText("รองเท้า");
                }
                else if (mType.getText().toString().trim().equals("หลูด")){
                    mResults.setText("ลิปสติก");
                }
                else if (mType.getText().toString().trim().equals("เริน")){
                    mResults.setText("บ้าน,เรือน");
                }
                else if (mType.getText().toString().trim().equals("ต่อเช้า")){
                    mResults.setText("พรุ่งนี้");
                }
                else if (mType.getText().toString().trim().equals("แรกวา")){
                    mResults.setText("เมื่อวาน");
                }
                else if (mType.getText().toString().trim().equals("ต่อรือ")){
                    mResults.setText("วันมะรืน");
                }
                else if (mType.getText().toString().trim().equals("ทั้งเพ")){
                    mResults.setText("ทั้งหมด");
                }
                else if (mType.getText().toString().trim().equals("ขบ")){
                    mResults.setText("กัด");
                }
                else if (mType.getText().toString().trim().equals("หาม้าย")){
                    mResults.setText("ไม่มี");
                }
                else if (mType.getText().toString().trim().equals("เอิด")){
                    mResults.setText("ทำตัวกร่าง");
                }
                else if (mType.getText().toString().trim().equals("หยบ")){
                    mResults.setText("แอบ,ซ่อน");
                }
                else if (mType.getText().toString().trim().equals("ตอใด")){
                    mResults.setText("เมื่อไหร่");
                }
                else if (mType.getText().toString().trim().equals("รถถีบ")){
                    mResults.setText("รถจักรยาน");
                }
                else if (mType.getText().toString().trim().equals("ไม่รู้หวัน")){
                    mResults.setText("ไม่รู้เรื่อง");
                }
                else if (mType.getText().toString().trim().equals("สากเบือ")){
                    mResults.setText("สากกะเบือ");
                }
                else if (mType.getText().toString().trim().equals("ตะ")){
                    mResults.setText("ได้ไหม");
                }
                else if (mType.getText().toString().trim().equals("เหล็กคูด")){
                    mResults.setText("กระต่ายขูดมะพร้าว");
                }
                else if (mType.getText().toString().trim().equals("จังเสีย")){
                    mResults.setText("เยอะ");
                }
                else if (mType.getText().toString().trim().equals("นายหัว")){
                    mResults.setText("เจ้านาย");
                }
                else if (mType.getText().toString().trim().equals("ชมพู่")){
                    mResults.setText("ฝรั่ง");
                }
                else if (mType.getText().toString().trim().equals("ไคร")){
                    mResults.setText("ตะไคร้");
                }
                else if (mType.getText().toString().trim().equals("หย่านัด")){
                    mResults.setText("สัปปะรด");
                }
                else if (mType.getText().toString().trim().equals("เบล่อ")){
                    mResults.setText("ไม่เอาไหน");
                }
                else if (mType.getText().toString().trim().equals("ด้น")){
                    mResults.setText("ดุร้าย");
                }
                else if (mType.getText().toString().trim().equals("ได้แรงอก")){
                    mResults.setText("รู้สึกพอใจอย่างมาก");
                }
                else if (mType.getText().toString().trim().equals("หิด")){
                    mResults.setText("เล็กน้อย");
                }
                else if (mType.getText().toString().trim().equals("หวังเหวิด")){
                    mResults.setText("เป็นห่วง กังวล");
                }
                else if (mType.getText().toString().trim().equals("ทำเฒ่า")){
                    mResults.setText("อวดดี");
                }
                else if (mType.getText().toString().trim().equals("หรอย")){
                    mResults.setText("อร่อย");
                }
                else if (mType.getText().toString().trim().equals("เอ่ม")){
                    mResults.setText("อิ่ม");
                }
                else if (mType.getText().toString().trim().equals("หาจก")){
                    mResults.setText("ตะกละ");
                }
                else if (mType.getText().toString().trim().equals("เเหม็ด")){
                    mResults.setText("หมด");
                }
                else if (mType.getText().toString().trim().equals("พี่บ่าว")){
                    mResults.setText("พี่ชาย");
                }
                else if (mType.getText().toString().trim().equals("สาวนุ้ย")){
                    mResults.setText("น้องสาว");
                }
                else if (mType.getText().toString().trim().equals("แขบ")){
                    mResults.setText("รีบ");
                }
                else if (mType.getText().toString().trim().equals("แล")){
                    mResults.setText("ดู");
                }
                else if (mType.getText().toString().trim().equals("หม้าย")){
                    mResults.setText("ไม่");
                }
                else {
                    mResults.setText("ไม่พบคำที่ค้นหา");
                }
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
